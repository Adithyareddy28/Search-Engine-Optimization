from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/keyword_research', methods=['POST'])
def keyword_research():
    keyword = request.form['keyword']
    # Simulate keyword research (in a real app, you'd use an API)
    suggestions = [f"{keyword} suggestion {i}" for i in range(1, 6)]
    return render_template('results.html', results=suggestions)

@app.route('/site_audit', methods=['POST'])
def site_audit():
    url = request.form['url']
    # Simple site audit (in a real app, you'd perform more checks)
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        title = soup.title.string if soup.title else 'No title found'
    except Exception as e:
        title = f"Error fetching URL: {str(e)}"
    return render_template('results.html', results=[f"Title: {title}"])

if __name__ == '__main__':
    app.run(debug=True)